from django.conf.urls import url, include

from plant.api import urls as api_urls
from frontend import urls as frontend_urls

urlpatterns = [
    url(r'^api/',
        include(api_urls, namespace='api')),
    url(r'',
        include(frontend_urls, namespace='')),
]