
def flatten(l):
    return (a for b in l for a in b)
