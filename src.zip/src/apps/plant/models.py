import hashlib

from django.contrib.auth.models import AbstractUser
from django.contrib.postgres.fields import JSONField
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

from adminsortable.models import SortableMixin
from simple_history.models import HistoricalRecords
from timezone_field import TimeZoneField

from .managers import UserManager, ValveManagerWithEvents


# Each key is a version number (semver), and each value is the
# default config. The semver gets added in as a key called `version`
# when calling `get_default_config`
DEFAULT_CONTROLLER_CONFIGS = {
    '1.0': {
        'user': {
            'watering_duration_seconds': 300,  # 5 minutes
            'watering_delay_seconds': 3540,  # 59 minutes
            'watering_schedule': [
                {'begin': '00:00', 'end': '23:59'}
            ],
            'soil_moisture_threshold': 50.0,
        },
        'system': {
            'sync_interval_seconds': 20 * 60,  # 20 minutes
            'system_clock_seconds': 60,
        }
    }
}

CONTROLLER_CONFIG_VERSIONS = list(DEFAULT_CONTROLLER_CONFIGS.keys())


def validate_user_config(config):
    from rest_framework.serializers import ValidationError

    version = config.get('version')
    if not version:
        raise ValidationError('Version not specified')
    if version not in CONTROLLER_CONFIG_VERSIONS:
        raise ValidationError(f'Unknown config version: "{version}"')

    expected_keys = set(DEFAULT_CONTROLLER_CONFIGS[version]['user'].keys())
    cu = config.get('user', {})
    intersection = set(cu.keys()) & expected_keys
    if intersection != expected_keys:
        key_list = ', '.join(expected_keys)
        raise ValidationError(
            f'The following values are expected: {key_list}')


def mcu_id_field(): return models.CharField(unique=True, max_length=128)

def thingspeak_channel_id_field(): return models.CharField(max_length=16)


class User(AbstractUser):
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    email = models.EmailField(max_length=255, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    def save(self, **k):
        self.username = hashlib.md5(str.encode(self.email)).hexdigest()
        self.email = self.email.lower()
        super(User, self).save(**k)


class Project(models.Model):
    """
    An installation at a location
    """
    name = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250)
    users = models.ManyToManyField(User, related_name='projects')
    address = models.TextField(null=True, blank=True)
    timezone = TimeZoneField()
    latitude = models.DecimalField(null=True, blank=True, max_digits=9, decimal_places=6)
    longitude = models.DecimalField(null=True, blank=True, max_digits=9, decimal_places=6)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Zone(models.Model):
    """
    A conceptual area in a Project
    """
    name = models.CharField(max_length=250)
    project = models.ForeignKey(Project, related_name='zones')
    plants = models.ManyToManyField(
        'plantdb.Plant', through='plant.PlantAssignment')

    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.project.name} - {self.name}'


class PlantAssignment(models.Model):
    plant = models.ForeignKey('plantdb.Plant')
    zone = models.ForeignKey(Zone)
    creator = models.ForeignKey(User)

    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)


class ControllerVersion(models.Model):
    """
    A version of MCU code with its own configuration
    """

    semver = models.CharField(
        max_length=32,
        verbose_name="Version number",
        help_text="Semantic version string, e.g. 3.2.1"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.semver

    def get_default_config(self):
        version = self.semver
        return dict(DEFAULT_CONTROLLER_CONFIGS[version], version=version)


class Controller(models.Model):
    """
    A microcontroller that controls valves and collects data from sensors
    and sends it back to us
    """

    mcu_id = mcu_id_field()

    # project = models.ForeignKey(Project, related_name='controllers')
    zone = models.OneToOneField(Zone, null=True)
    version = models.ForeignKey(ControllerVersion, on_delete=models.PROTECT)

    description = models.TextField(blank=True)
    modified_at = models.DateTimeField(auto_now=True)

    config = JSONField(null=True, blank=True)

    history = HistoricalRecords()

    @property
    def display_name(self):
        return f'Controller M-{self.mcu_id}'

    def __str__(self):
        return self.display_name + (
            f' ({self.zone})' if self.zone else ''
        )

    def save(self, *a, **k):
        "Create initial ControllerConfig"
        if not self.config:
            self.config = self.version.get_default_config()
        return super(Controller, self).save(*a, **k)

    @property
    def project(self):
        return self.zone.project


class Valve(models.Model):
    """
    A solenoid valve with associated flow rate sensor
    """

    mcu_id = mcu_id_field()
    thingspeak_channel_id = thingspeak_channel_id_field()

    controller = models.ForeignKey(Controller, on_delete=models.PROTECT, related_name='valves')
    name = models.CharField(max_length=250, blank=True, null=True)
    description = models.TextField(blank=True)
    modified_at = models.DateTimeField(auto_now=True)

    flow_rate_gph = models.DecimalField(
        max_digits=9, decimal_places=3,
        blank=True, null=True,
        verbose_name="Flow rate (gallons per hour)",
        help_text=(
            "The flow rate of this valve, used to calculate total water usage"
        )
    )

    objects = ValveManagerWithEvents()
    objects_sans_annotations = models.Manager()

    @property
    def display_name(self):
        identifier = self.thingspeak_channel_id
        model_name = self._meta.verbose_name.title()

        if self.name:
            return self.name
        elif self.mcu_id:
            return f'{model_name} M-{self.mcu_id}'
        else:
            return f"{model_name} TS-{self.thingspeak_channel_id}"

    def __str__(self): return f'{self.display_name} ({self.controller.zone})'


class Probe(models.Model):
    """
    An ESP8266 unit which reports its metrics
    """
    mcu_id = mcu_id_field()
    thingspeak_channel_id = thingspeak_channel_id_field()
    thingspeak_moisture_field = models.CharField(
        max_length=128, blank=True, null=True, default='field1')
    thingspeak_temperature_field = models.CharField(
        max_length=128, blank=True, null=True, default='field2')
    thingspeak_battery_field = models.CharField(
        max_length=128, blank=True, null=True, default='field3')
    legacy_last_watered_check = models.BooleanField(
        default=False,
        help_text=(
            "If checked, will pull from /status/last.json for last watered "
            "time. This only applies to the old system (pre-Brooklyn Grange)"
        )
    )

    name = models.CharField(max_length=250, blank=True, null=True)
    controller = models.ForeignKey('plant.Controller', related_name='probes')
    description = models.TextField(blank=True)
    modified_at = models.DateTimeField(auto_now=True)


    @property
    def display_name(self):
        identifier = self.thingspeak_channel_id
        model_name = self._meta.verbose_name.title()

        if self.name:
            return self.name
        elif self.thingspeak_channel_id:
            return f"{model_name} TS-{self.thingspeak_channel_id}"
        else:
            return f'{model_name} M-{self.mcu_id}'

    def __str__(self): return self.display_name

    # _display_order = models.PositiveIntegerField(default=0, editable=False, db_index=True)

    # class Meta:
    #     ordering = ['_display_order']


class ValveEvent(models.Model):

    VALVE_ON = 1
    VALVE_OFF = 2

    EVENT_TYPE_CHOICES = (
        (VALVE_ON, "Valve On"),
        (VALVE_OFF, "Valve Off"),
    )

    valve = models.ForeignKey(Valve, related_name="valve_events")
    created_at = models.DateTimeField(auto_now_add=True)
    event_type = models.SmallIntegerField(choices=EVENT_TYPE_CHOICES)


class FlowRateSensor(models.Model):
    """
    A flow rate sensor with a Thingspeak feed.
    This model is similar to `Valve` in that it captures info about water flow,
    but it has no API of its own. It just follows a thingspeak feed, and we
    periodically poll Thingspeak (currently using a cached view that makes a
    call for summed data) to update the dashboard view.
    """

    UNITS_LITERS_PER_MINUTE = 1
    UNITS_GALLONS_PER_HOUR = 2
    UNITS_CHOICES = (
        (UNITS_LITERS_PER_MINUTE, 'L/m'),
        (UNITS_GALLONS_PER_HOUR, 'gph'),
    )

    controller = models.ForeignKey(Controller, related_name='flow_rate_sensors')
    name = models.CharField(max_length=250)
    thingspeak_channel_id = thingspeak_channel_id_field()
    thingspeak_field_id = models.CharField(max_length=128)

    beginning_time = models.DateTimeField(null=True, blank=True)
    # last_updated = models.DateTimeField(null=True, blank=True)
    # total_flow = models.DecimalField(10, 3)
    units = models.PositiveSmallIntegerField(choices=UNITS_CHOICES)

    @property
    def display_name(self): return self.name

    def __str__(self): return self.display_name
