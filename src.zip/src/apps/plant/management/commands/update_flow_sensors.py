import os
import requests
from datetime import datetime, timedelta
import dateutil.parser

from django.core.management.base import BaseCommand, CommandError

from plant.models import FlowRateSensor


minute = timedelta(minutes=1)
hour = timedelta(hours=1)


class Command(BaseCommand):
    help = 'Periodically pull data from Thingspeak to update water flow totals. UNTESTED, UNUSED.'

    def add_arguments(self, parser):
        pass

    def handle(self, *args, **kwargs):
        for sensor in FlowRateSensor.objects.all():
            start_time_str = datetime.strftime(
                sensor.last_updated, '%Y-%M-%d %H:%M:%S'
            )
            url = 'https://api.thingspeak.com/channels/{}/feeds.json?{}'.format(
                sensor.thingspeak_channel_id,
                f'results=8000&start={start_time_str}'
            )
            response = requests.get(url)
            fieldname = sensor.thingspeak_field_id

            try:
                points = (
                    (
                        dateutil.parser.parse(f['created_at']),
                        float(f[fieldname] or 0)
                    )
                    for f in response.json()['feeds']
                )
            except KeyError:
                self.stdout.write(self.style.ERROR(
                    f"Couldn't read {url} for FlowRateSensor {sensor.id}"
                ))
                continue

            initial_time = last_time = sensor.last_updated
            last_value = None
            for p in points:
                if not last_value:
                    previous = p
                    continue
                else:
                    time, datum = p
                    prev_time, prev_datum = p
                    diff = time - last_time
                    avg = (prev_datum + datum) / 2
                    if sensor.units == FlowRateSensor.UNITS_LITERS_PER_MINUTE:
                        sensor.total_flow += avg * (diff * minute)
                    if sensor.units == FlowRateSensor.UNITS_LITERS_PER_MINUTE:
                        sensor.total_flow += avg * (diff * hour)
                    sensor.last_updated = time
                    previous = p


            sensor.save()

        self.stdout.write(self.style.SUCCESS('Import complete.'))
