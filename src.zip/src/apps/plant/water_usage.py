import datetime

from plant.models import ValveEvent


class WaterUsageError(Exception):
    pass


def get_total_watering_time(events):
    """
    Given a list of ValveEvents ordered ascending by created_at time,
    return a timedelta of the total time watered
    """

    expected_type = ValveEvent.VALVE_ON
    start_time = None
    waterings = 0
    duration = datetime.timedelta()

    for i, e in enumerate(events):
        # If the event type doesn't match the expectation,
        # i.e. if there are two consecutive ON or two consecutive OFF
        # events, just give up and raise an exception
        if e.event_type != (
            ValveEvent.VALVE_OFF if start_time else ValveEvent.VALVE_ON
        ):
            raise WaterUsageError(
                "Unexpected ValveEvent {} ({} parsed)".format(e.event_type, i)
            )

        if start_time:
            duration += (e.created_at - start_time)
            waterings += 1
            start_time = None
        else:
            start_time = e.created_at

    return duration, waterings
