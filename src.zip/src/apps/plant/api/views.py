import json
import requests
import dateutil.parser

from django.http import JsonResponse
from django.views.decorators.cache import cache_page
from django.utils import timezone

from rest_framework import generics, mixins, viewsets, status
from rest_framework.decorators import detail_route, list_route
from rest_framework import mixins
from rest_framework.response import Response
from rest_condition import Or, And

from plant import water_usage
from plant.models import (
    Controller, PlantAssignment, Project, Valve, FlowRateSensor, Zone
)
from plant.permissions import ValvePermission, OwnerPermission, AllowAnyGet
from plantdb.models import Plant
from . import serializers


@cache_page(60 * 60 * 12)  # 12 hours
def get_sensor_total(request, pk):
    lpm_to_gph = 15.8503
    sensor = FlowRateSensor.objects.get(pk=int(pk))
    now = timezone.now()
    url = 'https://api.thingspeak.com/channels/{}/feeds.json?{}'.format(
        sensor.thingspeak_channel_id,
        'average=daily'
    )
    response = requests.get(url)
    fieldname = sensor.thingspeak_field_id
    beginning = sensor.beginning_time
    feeds = [
        f for f in response.json()['feeds']
        if (
            not beginning or
            dateutil.parser.parse(f['created_at']) >= beginning
        )
    ]

    # puts data in gallons per hour
    unit_multiplier = (
        lpm_to_gph
        if sensor.units == FlowRateSensor.UNITS_LITERS_PER_MINUTE
        else 1.0
    )

    total_avg = sum(float(f[fieldname] or 0) for f in feeds)
    total = total_avg * unit_multiplier * 24
    since = feeds[0]['created_at']
    last = now

    unit = 'gallons'

    return JsonResponse({
        'since': str(since),
        'last': last.isoformat(timespec='seconds'),
        'total': total,
        'unit': unit
    })


class ProjectViewSet(viewsets.ModelViewSet):
    queryset = Project.objects.all()
    serializer_class = serializers.ProjectSerializer
    lookup_field = 'slug'
    # permission_classes = [permissions.IsAdminUser]


class ZoneViewSet(viewsets.ModelViewSet):
    queryset = Zone.objects.all()
    serializer_class = serializers.ZoneSerializer
    # lookup_field = 'slug'
    # permission_classes = [permissions.IsAdminUser]

    @detail_route(
        methods=['put'],
        permission_classes=[
            OwnerPermission(lambda zone: zone.project.users)
        ]
    )
    def plant_associations(self, request, pk):
        zone = self.get_object()
        plant_ids = json.loads(request.data['plant_ids'])
        for plant in Plant.objects.filter(id__in=plant_ids):
            pa, created = PlantAssignment.objects.get_or_create(
                zone=zone,
                plant=plant,
                defaults={
                    'creator': request.user,
                }
            )
            if not created:
                pa.plant = plant
                pa.save()
        PlantAssignment.objects.filter(
            zone=zone
        ).exclude(plant_id__in=plant_ids).delete()

        return Response({})


class ValveViewSet(viewsets.ModelViewSet):
    queryset = Valve.objects.all()
    serializer_class = serializers.ValveSerializer
    lookup_field = 'mcu_id'
    # permission_classes = [permissions.IsAdminUser]

    @detail_route(
        methods=['get'],
        permission_classes=[ValvePermission],
        authentication_classes=[]
    )
    def water_usage_stats(self, request, mcu_id):
        """
        Get total gallons used based on the whole history of ValveEvent records
        TODO: cache properly, because this can get expensive
        """

        valve = self.get_object()
        if not valve.flow_rate_gph:
            return Response({
                'error': 'No flow rate specified for this valve'
            })

        events = valve.valve_events.order_by('created_at').iterator()
        try:
            duration, waterings = water_usage.get_total_watering_time(events)
        except water_usage.WaterUsageError as e:
            return Response({
                'error': str(e)
            })
        hours = duration.total_seconds() / 60 / 60
        gallons = float(valve.flow_rate_gph) * hours
        return Response({
            'hours': hours,
            'waterings': waterings,
            'gallons': gallons,
        })

    @detail_route(
        methods=['post'],
        permission_classes=[ValvePermission],
        authentication_classes=[]
    )
    def record_event(self, request, mcu_id):
        """
        Publicly available endpoint to record valve events.
        Often called directly from a Valve out in the real world.
        **UNAUTHENTICATED!**
        """

        valve = self.get_object()
        serializer = serializers.ValveEventSerializer(data=request.data)

        if serializer.is_valid():
            valve.valve_events.create(**serializer.data)
            return Response(status=status.HTTP_200_OK)
        else:
            if serializer.errors.keys() == {'event_type'}:
                # Create the event even if the event_type is invalid,
                # so we can at least see what crazy erroneous value it did get.
                valve.valve_events.create(**serializer.data)
            return Response(serializer.errors,
                            status=status.HTTP_400_BAD_REQUEST)


class ControllerConfigView(generics.RetrieveUpdateAPIView):
    lookup_field = 'mcu_id'
    serializer_class = serializers.ControllerConfigSerializer
    queryset = Controller.objects.all()
    permission_classes = [
        Or(
            AllowAnyGet,
            OwnerPermission(lambda c: c.zone.project.users)
        )
    ]


# class ControllerConfigViewSet(
#     mixins.RetrieveModelMixin,
#     mixins.UpdateModelMixin,
#     viewsets.GenericViewSet
# ):
#     """
#     Manage Controller Configs
#     """
#     queryset = ControllerConfig.objects.all()
#     serializer_class = serializers.ControllerConfigSerializer
#     lookup_field = 'controller__mcu_id'

#     @detail_route(
#         methods=['get'],
#         permission_classes=[ValvePermission],
#         authentication_classes=[],
#     )
#     def read(self, request, controller__mcu_id):
#         """
#         Publicly available endpoint to fetch valve config.
#         Often called directly from a Controller out in the real world.
#         **UNAUTHENTICATED!**
#         """
#         config = self.get_object()
#         serializer = serializers.ControllerConfigSerializer(config)
#         return Response(serializer.data)
