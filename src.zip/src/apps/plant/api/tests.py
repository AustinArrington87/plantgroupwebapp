import datetime
import json
from unittest import skip

from test_plus.test import TestCase
from rest_framework.test import APITestCase

from plant import factories
from plant.models import Controller, Probe, Valve, ValveEvent, Project
from plant.water_usage import get_total_watering_time, WaterUsageError
from plantdb.factories import PlantFactory


class BaseCase(TestCase, APITestCase):

    def login(self, user):
        return super(BaseCase, self).login(
            email=user.email,
            password='password'
        )


class ProjectTests(TestCase):

    def setUp(self):
        self.ctrl = factories.ControllerFactory.create()

    def test_get_controller_config(self):
        response = self.get('plant:api:project-list')
        self.response_200()
        controller = response.data[0]['zones'][0]['controller']
        self.assertEqual(controller['config'], self.ctrl.config)


class ControllerConfigTests(TestCase, APITestCase):

    def setUp(self):
        self.ctrl = factories.ControllerFactory.create()
        self.project = self.ctrl.zone.project
        self.user = factories.UserFactory.create(username='ha')
        self.user2 = factories.UserFactory.create(username='he')
        self.project.users.add(self.user)

    def test_patch_permission(self):
        """
        Config is inaccessible to non-project owners
        """
        with self.login(
            email=self.user2.email, password='password'
        ):
            response = self.patch(
                self.reverse(
                    'plant:api:controller-config',
                    mcu_id=self.ctrl.mcu_id
                ),
                data={'config': '{}'},
                format='json',
            )
            self.assertEqual(response.status_code, 403)

    def test_patch(self):
        """
        Test that ONLY 'user' config is updated,
        and that PUT is identical to PATCH
        """
        user = self.ctrl.zone.project.users.first()
        with self.login(
            email=user.email, password='password'
        ):
            desired_userdata = {
                'watering_duration_seconds': 99,
                'watering_delay_seconds': 99,
                'watering_schedule': [
                    {'begin': '00:00', 'end': '11:55'},
                    {'begin': '12:00', 'end': '12:10'},
                ],
                'soil_moisture_threshold': 99
            }
            request_data = {
                'config': json.dumps({
                    'version': '<IGNORED>',
                    'system': '<IGNORED>',
                    'something-else': '<IGNORED>',
                    'user': desired_userdata
                })
            }
            response = self.patch(
                self.reverse(
                    'plant:api:controller-config',
                    mcu_id=self.ctrl.mcu_id
                ),
                data=request_data,
                format='json',
            )

            response_put = self.put(
                self.reverse(
                    'plant:api:controller-config',
                    mcu_id=self.ctrl.mcu_id
                ),
                data=request_data,
                format='json',
            )
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.data, response_put.data)

            updated_userdata = response.data['config']['user']
            updated_systemdata = response.data['config']['system']

            self.assertEqual(updated_userdata, desired_userdata)
            self.assertEqual(updated_systemdata, self.ctrl.config['system'])
            self.assertEqual(response.data['config']['version'], self.ctrl.config['version'])

    def test_get(self):
        """
        Test that controller config is publicly available to read
        """

        response = self.get(
            self.reverse(
                'plant:api:controller-config',
                mcu_id=self.ctrl.mcu_id
            )
        )

        self.assertEqual(response.status_code, 200)

        userdata = response.data['config']['user']
        systemdata = response.data['config']['system']
        version = response.data['config']['version']

        self.assertEqual(userdata, self.ctrl.config['user'])
        self.assertEqual(systemdata, self.ctrl.config['system'])
        self.assertEqual(version, self.ctrl.config['version'])


class ValveEventTests(TestCase):

    def setUp(self):
        self.valve = factories.ValveFactory.create()
        self.endpoint = 'plant:api:valve-record-event'

    def _create_event(self, valve, event_type):
        return self.post(
            self.endpoint, mcu_id=valve.mcu_id, data={"event_type": event_type}
        )

    def test_success(self):
        "An event is successfully recorded"
        self._create_event(self.valve, ValveEvent.VALVE_ON)
        self.response_200()
        self.assertEqual(self.valve.valve_events.count(), 1)

    def test_valve_not_found(self):
        "An event is not recorded for a nonexistent valve"
        self.post(self.endpoint, mcu_id=0, data={"event_type": 1})
        self.response_404()
        self.assertEqual(self.valve.valve_events.count(), 0)

    def test_invalid_event_type(self):
        "An event is recorded even if the event_type is unrecognized"
        self._create_event(self.valve, 99)
        self.response_400()
        self.assertEqual(self.valve.valve_events.count(), 1)

    def test_is_currently_watering(self):
        "An event is successfully recorded"

        self._create_event(self.valve, ValveEvent.VALVE_ON)
        d = Valve.objects.all().get(pk=self.valve.pk)
        self.assertTrue(d.is_currently_watering)

        self._create_event(self.valve, ValveEvent.VALVE_OFF)
        d = Valve.objects.all().get(pk=self.valve.pk)
        self.assertFalse(d.is_currently_watering)

        self._create_event(self.valve, ValveEvent.VALVE_ON)
        d = Valve.objects.all().get(pk=self.valve.pk)
        self.assertTrue(d.is_currently_watering)

    def test_last_watering_time(self):
        "An event is successfully recorded"

        self._create_event(self.valve, ValveEvent.VALVE_ON)
        event_on = ValveEvent.objects.last()
        self._create_event(self.valve, ValveEvent.VALVE_OFF)
        event_off = ValveEvent.objects.last()

        d = Valve.objects.all().get(pk=self.valve.pk)
        self.assertEqual(d.last_watering_start_time, event_on.created_at)
        self.assertEqual(d.last_watering_time, event_off.created_at)


class WaterUsageTests(TestCase):

    def setUp(self):
        now = datetime.datetime.now(datetime.timezone.utc)
        self.endpoint = 'plant:api:valve-water-usage-stats'
        self.valve = factories.ValveFactory.create(flow_rate_gph=100)
        for i in range(6):

            ve = ValveEvent.objects.create(
                valve=self.valve,
                event_type=(
                    ValveEvent.VALVE_OFF if i % 2 else ValveEvent.VALVE_ON
                )
            )
            ve.created_at = now + datetime.timedelta(minutes=(i * 30))
            ve.save()

    def test_total_watering_time(self):
        "Can calculate the total watering time"
        events = self.valve.valve_events.order_by('created_at').iterator()
        duration, waterings = get_total_watering_time(events)
        self.assertEqual(duration.total_seconds(), 90 * 60)
        self.assertEqual(waterings, 3)

    def test_total_watering_time_failure(self):
        "Error is raised for missing events"
        events = list(self.valve.valve_events.order_by('created_at'))
        modified_events = events[:3] + events[4:]
        with self.assertRaises(WaterUsageError):
            get_total_watering_time(modified_events)

    def test_watering_stats_endpoint(self):
        "Watering stats API returns correct data"
        response = self.get(self.endpoint, mcu_id=self.valve.mcu_id)

        self.assertEqual(response.data['hours'], 1.5)
        self.assertEqual(response.data['waterings'], 3)
        self.assertEqual(response.data['gallons'], 150)

    def test_watering_stats_endpoint_failure_no_flow_rate(self):
        "Watering stats API returns error if valve has no flow rate set"
        self.valve.flow_rate_gph = None
        self.valve.save()
        response = self.get(self.endpoint, mcu_id=self.valve.mcu_id)
        self.assertIn('error', response.data)

    def test_watering_stats_endpoint_failure_missing_data_point(self):
        """
        Watering stats API returns error if missing data point
        XXX: not sure what this actually tests
        """
        self.valve.valve_events.all()[3].delete()
        response = self.get(self.endpoint, mcu_id=self.valve.mcu_id)
        self.assertIn('error', response.data)


class PlantAssociationTests(BaseCase):

    def setUp(self):
        self.endpoint = 'plant:api:zone-plant-associations'
        self.user = factories.UserFactory.create()
        self.user2 = factories.UserFactory.create()
        self.project = factories.ProjectFactory.create()
        self.zones = factories.ZoneFactory.create_batch(
            3, project=self.project
        )
        self.project.users.add(self.user)
        self.plants = PlantFactory.create_batch(10)

    def test_add_associations(self):
        zone1, zone2, zone3 = self.zones
        with self.login(self.user):
            self.put(
                self.endpoint,
                pk=zone1.id,
                data={
                    'plant_ids': json.dumps([p.id for p in self.plants[:3]])
                })
            self.response_200()
            zone1.refresh_from_db()
            self.assertCountEqual(
                zone1.plants.all(),
                self.plants[:3]
            )

    def test_remove_associations(self):
        zone1, zone2, zone3 = self.zones
        with self.login(self.user):
            self.put(
                self.endpoint,
                pk=zone1.id,
                data={
                    'plant_ids': json.dumps([p.id for p in self.plants[:5]])
                })
            self.response_200()
            self.put(
                self.endpoint,
                pk=zone1.id,
                data={
                    'plant_ids': json.dumps([])
                })
            self.response_200()
            zone1.refresh_from_db()
            self.assertCountEqual(zone1.plants.all(), [])

    def test_must_be_project_owner(self):
        zone1, zone2, zone3 = self.zones
        with self.login(self.user2):
            self.put(
                self.endpoint,
                pk=zone1.id,
                data={
                    'plant_ids': json.dumps([p.id for p in self.plants[:3]])
                })
            self.response_403()
