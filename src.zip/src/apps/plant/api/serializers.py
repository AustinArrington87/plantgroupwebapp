import datetime

from rest_framework import serializers

from plant.models import (
    Project, Probe, Controller, Valve, ValveEvent, FlowRateSensor
)
from plantdb.serializers import PlantSerializer


class ProbeSerializer(serializers.ModelSerializer):

    class Meta:
        model = Probe
        fields = (
            'id', 'mcu_id', 'thingspeak_channel_id',
            'thingspeak_moisture_field',
            'thingspeak_temperature_field',
            'thingspeak_battery_field',
            'legacy_last_watered_check',
            'display_name'
        )

class ValveSerializer(serializers.ModelSerializer):

    is_currently_watering = serializers.BooleanField(read_only=True)
    last_watering_time = serializers.DateTimeField(read_only=True)

    class Meta:
        model = Valve
        fields = (
            'id', 'mcu_id', 'thingspeak_channel_id',
            'last_watering_time',
            'is_currently_watering',
            'display_name'
        )

class FlowRateSensorSerializer(serializers.ModelSerializer):

    class Meta:
        model = FlowRateSensor
        fields = (
            'id', 'display_name',
        )


class ValveEventSerializer(serializers.ModelSerializer):

    created_at = serializers.ReadOnlyField()

    class Meta:
        model = ValveEvent
        fields = ('valve_id', 'event_type', 'created_at')


class ControllerSerializer(serializers.ModelSerializer):

    valves = ValveSerializer(many=True)
    flow_rate_sensors = FlowRateSensorSerializer(many=True)
    probes = ProbeSerializer(many=True)
    config = serializers.JSONField()
    display_name = serializers.SerializerMethodField()

    def get_display_name(self, obj):
        return obj.display_name

    class Meta:
        model = Controller
        fields = (
            'id',
            'mcu_id',
            'valves',
            'flow_rate_sensors',
            'probes',
            'config',
            'display_name',
        )


class ControllerConfigSerializer(serializers.ModelSerializer):
    """
    Queried directly by a MCU out in the field
    """

    config = serializers.JSONField(binary=False)
    local_time = serializers.SerializerMethodField()

    def get_local_time(self, obj):
        """
        TODO: can eventually just parse from Response Header
        """
        t = datetime.datetime.now(tz=obj.zone.project.timezone)
        return t.strftime('%H:%M:%S')

    class Meta:
        model = Controller
        fields = ('id', 'config', 'zone', 'local_time')

    def update(self, instance, validated_data):
        config = validated_data['config']
        instance.config['user'] = config['user']
        instance.save()

        return instance


class ZoneSerializer(serializers.ModelSerializer):

    controller = ControllerSerializer()
    plants = PlantSerializer(many=True)

    class Meta:
        model = Project
        fields = (
            'id',
            'name',
            'controller',
            'plants',
        )


class ProjectSerializer(serializers.ModelSerializer):

    zones = ZoneSerializer(many=True)

    class Meta:
        model = Project
        fields = (
            'id',
            'name',
            'slug',
            'address',
            'latitude',
            'longitude',
            'zones',
        )
