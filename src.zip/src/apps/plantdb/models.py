from django.db import models

from plantdb.fields import ChoiceArrayField

class Plant(models.Model):

    MOISTURE_IN_WATER = 10
    MOISTURE_WET = 20
    MOISTURE_WET_MESIC = 30
    MOISTURE_MESIC = 40
    MOISTURE_DRY_MESIC = 50
    MOISTURE_DRY = 60

    MOISTURE_CHOICES = (
        (MOISTURE_IN_WATER, "In Water"),
        (MOISTURE_WET, "Wet"),
        (MOISTURE_WET_MESIC, "Wet Mesic"),
        (MOISTURE_MESIC, "Mesic"),
        (MOISTURE_DRY_MESIC, "Dry Mesic"),
        (MOISTURE_DRY, "Dry"),
    )
    MOISTURE_LOOKUP = dict(MOISTURE_CHOICES)

    SUNLIGHT_FULL_SUN = 10
    SUNLIGHT_FULL_SUN_TO_PARTIAL = 20
    SUNLIGHT_PARTIAL = 30
    SUNLIGHT_PARTIAL_TO_FULL_SHADE = 40
    SUNLIGHT_FULL_SHADE = 50

    SUNLIGHT_CHOICES = (
        (SUNLIGHT_FULL_SUN, "Full Sun"),
        (SUNLIGHT_FULL_SUN_TO_PARTIAL, "Full Sun to Partial Shade"),
        (SUNLIGHT_PARTIAL, "Partial or Dappled Shade"),
        (SUNLIGHT_PARTIAL_TO_FULL_SHADE, "Partial Shade to Full Shade"),
        (SUNLIGHT_FULL_SHADE, "Full Shade"),
    )
    SUNLIGHT_LOOKUP = dict(SUNLIGHT_CHOICES)

    HARDINESS_REVERSE_LOOKUP = dict(
        (f"{n + 1}{c}", ((n + 1) * 10) + 5 * i)
        for n in range(13)
        for i, c in enumerate('ab')
    )

    HARDINESS_CHOICES = tuple(
        (v, k) for k, v in HARDINESS_REVERSE_LOOKUP.items()
    )
    HARDINESS_LOOKUP = dict(HARDINESS_CHOICES)

    common_name = models.CharField(max_length=250)
    scientific_name = models.CharField(max_length=250)

    moisture_needs = ChoiceArrayField(
        models.PositiveSmallIntegerField(choices=MOISTURE_CHOICES)
    )
    sunlight_needs = ChoiceArrayField(
        models.PositiveSmallIntegerField(choices=SUNLIGHT_CHOICES)
    )
    hardiness_zones = ChoiceArrayField(
        models.PositiveSmallIntegerField(choices=HARDINESS_CHOICES)
    )

    image = models.ImageField(null=True, blank=True)

    verified = models.BooleanField(
        default=True, help_text=(
            "Was this plant verified by PG staff, or automatically imported?"
        )
    )
    garden_org_id = models.CharField(null=True, blank=True, max_length=32)

    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        if self.common_name and self.scientific_name:
            return f'{self.scientific_name} ({self.common_name})'
        else:
            return self.scientific_name or self.common_name

    @property
    def garden_org_url(self):
        return f'https://garden.org/plants/view/{self.garden_org_id}/'
