from django.db.models import Q
from django.http import JsonResponse
from rest_framework import viewsets

from plantdb.models import Plant
from plantdb.serializers import PlantSerializer


class PlantViewSet(viewsets.ModelViewSet):
    queryset = Plant.objects.all()
    serializer_class = PlantSerializer


def search(request):
    NUM_TO_GET = 25

    if request.method == 'GET':
        query = request.GET['q']
        results = Plant.objects.filter(
            Q(common_name__istartswith=query) |
            Q(scientific_name__istartswith=query)
        ).order_by(
            'scientific_name', 'common_name'
        )

        return JsonResponse({
            'results': [
                {
                    'id': p.id,
                    'display_name': str(p)
                }
                for p in results[:NUM_TO_GET]
            ]
        })
