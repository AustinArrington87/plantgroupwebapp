
from rest_framework import serializers

from plantdb.models import Plant


class PlantSerializer(serializers.ModelSerializer):

    display_name = serializers.SerializerMethodField()

    def get_display_name(self, obj):
        return str(obj)

    class Meta:
        model = Plant
        fields = (
            'id', 'display_name', 'common_name', 'scientific_name', 'image',
            'moisture_needs', 'sunlight_needs', 'hardiness_zones'
        )
