import csv
import os
from collections import defaultdict

from django.core.management.base import BaseCommand, CommandError

from plantdb.models import Plant
from plant.utils import flatten

water_values = dict((
  ("1593", Plant.MOISTURE_IN_WATER),
  ("1594", Plant.MOISTURE_WET),
  ("1595", Plant.MOISTURE_WET_MESIC),
  ("1596", Plant.MOISTURE_MESIC),
  ("1597", Plant.MOISTURE_DRY_MESIC),
  ("1598", Plant.MOISTURE_DRY),
))

sun_values = dict((
    ("12", Plant.SUNLIGHT_FULL_SUN),
    ("13", Plant.SUNLIGHT_FULL_SUN_TO_PARTIAL),
    ("14", Plant.SUNLIGHT_PARTIAL),
    ("15", Plant.SUNLIGHT_PARTIAL_TO_FULL_SHADE),
    ("16", Plant.SUNLIGHT_FULL_SHADE),
))

hardiness_values = dict(
    (k, [Plant.HARDINESS_REVERSE_LOOKUP[x] for x in v]) for k, v in (
        ("290", ['2a', '2b']),
        ("17", ['3a', '3b']),
        ("18", ['4a']),
        ("19", ['4b']),
        ("20", ['5a']),
        ("21", ['5b']),
        ("22", ['6a']),
        ("23", ['6b']),
        ("24", ['7a']),
        ("25", ['7b']),
        ("26", ['8a']),
        ("27", ['8b']),
        ("28", ['9a']),
        ("29", ['9b']),
        ("30", ['10a']),
        ("31", ['10b']),
        ("32", ['11a', '11b']),
        ("1671", ['12a', '12b']),
        ("1672", ['13a', '13b']),
    ))

class Command(BaseCommand):
    help = 'Import scraped data from garden.org'

    def add_arguments(self, parser):
        parser.add_argument('filename', type=str)

    def handle(self, *args, **kwargs):
        filename = kwargs['filename']
        entries = defaultdict(set)
        plants = []
        with open(filename, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            headers = next(reader)
            for row in reader:
                data = dict(zip(headers, row))
                moisture = [water_values[d] for d in data['water'].split(',')]
                sunlight = [sun_values[d] for d in data['sun'].split(',')]
                hardiness = list(set(flatten(
                    hardiness_values[d] for d in data['hardiness'].split(',')
                )))
                plants.append(Plant(
                    garden_org_id=data['garden_id'],
                    common_name=data['common_name'],
                    scientific_name=data['scientific_name'],
                    moisture_needs=moisture,
                    sunlight_needs=sunlight,
                    hardiness_zones=hardiness,
                    verified=False
                ))
        Plant.objects.bulk_create(plants)

        self.stdout.write(self.style.SUCCESS('Import complete.'))
