from django.conf.urls import url, include

from frontend import views

urlpatterns = [
    url(r'^$', views.LoginRedirect.as_view(), name='main'),
    url(r'^projects/$', views.ProjectListView.as_view(), name='project_list'),
    url(r'^projects/(?P<slug>[\w-]+)/sensors/$', views.ProjectDashboardSensorsView.as_view(), name='project_dashboard_sensors'),
    url(r'^projects/(?P<slug>[\w-]+)/plants/$', views.ProjectDashboardPlantsView.as_view(), name='project_dashboard_plants'),
    url(r'^projects/(?P<slug>[\w-]+)/impact/$', views.ProjectDashboardImpactView.as_view(), name='project_dashboard_impact'),
]