from django.core.urlresolvers import reverse
from django.views.generic import TemplateView, RedirectView
from urllib.parse import urlencode

from plant.models import Project


class ProjectListView(TemplateView):
    template_name = 'project_list.html'

    def get_context_data(self, **k):
        user = self.request.user
        ctx = super().get_context_data(**k)
        ctx['projects'] = Project.objects.filter(users=user)
        return ctx


class ProjectDashboardBase(TemplateView):

    def get_context_data(self, **k):
        ctx = super().get_context_data(**k)
        slug = k['slug']
        project = Project.objects.prefetch_related(
            'zones__controller',
            'zones__controller__valves',
            'zones__controller__probes',
        ).get(slug=slug)
        ctx['project'] = project
        return ctx


class ProjectDashboardSensorsView(ProjectDashboardBase):
    template_name = 'project_dashboard_sensors.html'


class ProjectDashboardPlantsView(ProjectDashboardBase):
    template_name = 'project_dashboard_plants.html'


class ProjectDashboardImpactView(ProjectDashboardBase):
    template_name = 'project_dashboard_impact.html'



class LoginRedirect(RedirectView):
    """
    View to determine an appropriate auth location for a user, logged in or no.
    MarketPlace and PrivatePortal users can go to either a log in or
    registration view. We attempt to detect a cookie (cs_did_auth) signifying
    a user has logged into the private portal previously. If they have,
    redirect them to the accounts/log in view. If not, redirect them to the
    accounts/register view. Note that if they're already logged in, take
    them to the most relevant location.
    """
    permanent = False

    def get_redirect_url(self, *args, **kwargs):
        if self.request.user.is_authenticated():
            url = reverse('plant:project_list')
        else:
            url = reverse('auth:login')
        qs = urlencode(self.request.GET)
        if qs:
            url += '?' + qs
        return url
