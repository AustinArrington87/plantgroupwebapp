from django.conf.urls import include, url
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.core.urlresolvers import reverse_lazy

from django_js_reverse.views import urls_js
from django.contrib.auth.views import password_reset
import password_reset.urls

from .forms import LoginForm

urlpatterns = [
    url(r'^admin/',
        include(admin.site.urls),
        name='admin'),

    url(r'^password-reset/', include('password_reset.urls')),

    url(r'^accounts/', include('django.contrib.auth.urls', namespace='auth')),

    url(r'^jsreverse/$',
        urls_js,
        name='js_reverse'),

    url(r'',
        include('plant.urls', namespace="plant")),

    url(r'',
        include('plantdb.urls', namespace="plantdb")),
        
]
