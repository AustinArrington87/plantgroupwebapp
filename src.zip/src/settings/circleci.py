import os

from django.core.urlresolvers import reverse_lazy

from .common import *

DEBUG = False

ALLOWED_HOSTS = [
    '*'  # TODO: Change when sure of hostname
    # '0.0.0.0'
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'PORT': '5432',
        'HOST': 'localhost',
        'NAME': 'circle_test',
        'USER': 'ubuntu',
        'PASSWORD': '',
        'OPTIONS': {
            'connect_timeout': '10'
        }
    }
}

STATIC_ROOT = '/staticfiles'

STATICFILES_DIRS += [
    os.path.join(BASE_DIR, 'static'),
]

# WEBPACK
WEBPACK_LOADER = {
    'DEFAULT': {
        'BUNDLE_DIR_NAME': 'bundles/',  # must end with slash
        'STATS_FILE': '/webpack-stats.json',
    }
}