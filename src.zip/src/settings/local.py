import os

from django.core.urlresolvers import reverse_lazy

from .common import *

DEBUG = True

INTERNAL_IPS = [
    'localhost',
    '0.0.0.0',
    '127.0.0.1'
]

ALLOWED_HOSTS = '*'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'HOST': 'localhost',
        'NAME': 'plant_webapp',
        'USER': 'plant_webapp',
        'PORT': '5454',
        'PASSWORD': '',
    },
}

WEBPACK_LOADER = {
    'DEFAULT': {
        'BUNDLE_DIR_NAME': 'http://localhost:3333/static/bundles/',
        'STATS_FILE': '../common/webpack-stats.json',
    }
}

STATICFILES_DIRS += [
    # os.path.join(BASE_DIR, '..', 'shared/webpack'),
]

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
DEFAULT_FROM_EMAIL = 'PLANT Group <no-reply@plantgroup.co>'

AWS_SES_REGION_NAME = 'us-west-2'
AWS_SES_REGION_ENDPOINT = 'email.us-west-2.amazonaws.com'
AWS_SES_ACCESS_KEY_ID = 'AKIAJF6DPNFVGTZZH3IA'
AWS_SES_SECRET_ACCESS_KEY = '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'
