import os

from django.core.urlresolvers import reverse_lazy

from .common import *

DEBUG = False

ALLOWED_HOSTS = [
    'app.plantgroup.co',
    'beta.plantgroup.co',
]

# USE_X_FORWARDED_HOST = True

COMPRESS_OFFLINE = True
COMPRESS_ENABLED = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'PORT': '5432',
        'HOST': secrets['database']['host'],
        'NAME': secrets['database']['name'],
        'USER': secrets['database']['user'],
        'PASSWORD': secrets['database']['password'],
        'OPTIONS': {
            'connect_timeout': '10'
        }
    }
}

STATIC_ROOT = '/staticfiles'

STATICFILES_DIRS += [
    os.path.join(BASE_DIR, 'static'),
]

# WEBPACK
WEBPACK_LOADER = {
    'DEFAULT': {
        'BUNDLE_DIR_NAME': 'bundles/',  # must end with slash
        'STATS_FILE': '/common/webpack-stats.json',
    }
}

# EMAILS
EMAIL_BACKEND = 'django_ses.SESBackend'
DEFAULT_FROM_EMAIL = 'PLANT Group <no-reply@plantgroup.co>'
