import os

from django.core.urlresolvers import reverse_lazy

from .common import *

DEBUG = True

INTERNAL_IPS = [
    'localhost',
    '0.0.0.0',
    '127.0.0.1'
]

ALLOWED_HOSTS = INTERNAL_IPS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'HOST': 'postgres',  # magic link via docker-compose
        'PORT': '5432',
        'NAME': 'plant_webapp_dev',
        'USER': 'plant_webapp_dev',
        'PASSWORD': '',
    },
    # 'sqlite': {
    #     'ENGINE': 'django.db.backends.sqlite3',
    #     'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    # }
}

WEBPACK_LOADER = {
    'DEFAULT': {
        'BUNDLE_DIR_NAME': 'http://localhost:3333/static/bundles/',
        # 'BUNDLE_DIR_NAME': 'bundles/',
        'STATS_FILE': '/shared/webpack/webpack-stats.json',
        # 'STATS_FILE': os.path.join(BASE_DIR, 'webpack-stats.json'),
    }
}

STATICFILES_DIRS += [
    os.path.join(BASE_DIR, '..', 'shared/webpack'),
]
