from django.contrib.staticfiles.storage import staticfiles_storage
from django.urls import reverse

from jinja2 import Environment


def environment(**opts):
    if not 'extensions' in opts:
        opts['extensions'] = []
    env = Environment(**opts)
    env.globals.update({
        'static': staticfiles_storage.url,
        'url': reverse,
    })
    return env