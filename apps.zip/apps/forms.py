from django import forms
from django.contrib.auth import forms as auth_forms

from plant.models import User

class LoginForm(auth_forms.AuthenticationForm):
    class Meta:
        model = User
        exclude = ('email',)

    username = forms.EmailField(max_length=64)

    def clean_email(self):
        email = self.cleaned_data['username']
        return email