from django.contrib.auth.models import BaseUserManager
from django.db import models
from django.db.models.expressions import RawSQL


class UserManager(BaseUserManager):
    """
    A custom user manager to deal with emails as unique identifiers for auth
    instead of usernames. The default that's used is "UserManager"
    """
    
    def get_by_natural_key(self, username):
        return self.get(email__iexact=username)

    def _create_user(self, email, password, **extra_fields):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('The Email must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        return self._create_user(email, password, **extra_fields)


class ValveManagerWithEvents(models.Manager):
    """
    Annotate Valve queryset to get info about events in a single query
    (albeit with many subqueries)
    """

    def get_queryset(self):
        from .models import Valve, ValveEvent

        valve_table = Valve._meta.db_table
        event_table = ValveEvent._meta.db_table
        event_on = ValveEvent.VALVE_ON
        event_off = ValveEvent.VALVE_OFF

        return super().get_queryset().annotate(
            last_watering_time=RawSQL("""
                SELECT e.created_at
                FROM {event_table} e
                WHERE e.event_type = %s
                  AND e.valve_id = {valve_table}.id
                ORDER BY e.created_at DESC
                LIMIT 1
                """.format(event_table=event_table, valve_table=valve_table),
                [event_off],
                output_field=models.DateTimeField()
            ),
            last_watering_start_time=RawSQL("""
                SELECT e.created_at
                FROM {event_table} e
                WHERE e.event_type = %s
                  AND e.valve_id = {valve_table}.id
                ORDER BY e.created_at DESC
                LIMIT 1
                """.format(event_table=event_table, valve_table=valve_table),
                [event_on],
                output_field=models.DateTimeField()
            ),
            is_currently_watering=RawSQL("""
                SELECT e.event_type = %s
                FROM {event_table} e
                WHERE e.event_type IN (%s, %s)
                  AND e.valve_id = {valve_table}.id
                ORDER BY e.created_at DESC
                LIMIT 1
                """.format(event_table=event_table, valve_table=valve_table),
                (event_on, event_on, event_off),
                output_field=models.BooleanField()
            ),
        )
