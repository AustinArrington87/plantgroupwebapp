from django import forms
from django.contrib import admin
from django.contrib.auth import admin as auth_admin

from adminsortable.admin import SortableAdmin
from simple_history.admin import SimpleHistoryAdmin

from . import models
import plantdb.models
from plantdb.models import Plant


class UserCreationForm(auth_admin.UserCreationForm):
    email = forms.EmailField(label="Email")
    class Meta:
        model = models.User
        exclude = ('username',)


class ProjectInline(admin.TabularInline):
    model = models.User.projects.through
    filter_horizonal = ('projects',)


class UserAdmin(auth_admin.UserAdmin):
    list_display = ('email', 'first_name', 'last_name', 'is_staff')
    readonly_fields = ('username',)

    add_form = UserCreationForm
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2')}
        ),
    )

    inlines = [ProjectInline]

    def get_fieldsets(self, request, obj=None):
        """
        Put the first fieldset, containing username and password,
        at the bottom, and rename its header.
        """
        fieldsets = super().get_fieldsets(request, obj)
        x, internal_fields = fieldsets[0]
        internals = ("Internals", internal_fields)
        return fieldsets[1:] + (internals,)


class ProjectAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug": ("name",)}
    filter_horizontal = ('users',)


# class ControllerConfigInline(admin.StackedInline):
#     model = models.ControllerConfig


class ControllerAdmin(SimpleHistoryAdmin):
    readonly_fields = ('config',)

    # def formfield_for_foreignkey(self, db_field, request, **k):
    #     if db_field.name == "zone":
    #         k['queryset'] = 'TODO'
    #     return super().formfield_for_foreignkey(db_field, request, **k)


class ControllerVersionAdmin(admin.ModelAdmin):
    pass


# class ControllerConfigAdmin(SimpleHistoryAdmin):
#     readonly_fields = ('modified_at',)
#     list_display = (
#         'controller',
#         'watering_frequency_per_day',
#         'watering_duration_seconds',
#         'modified_at',
#     )


class FlowRateSensorAdmin(SortableAdmin):
    pass


class ValveAdmin(SortableAdmin):
    pass


class ZoneAdmin(SortableAdmin):
    pass


class ProbeAdmin(SortableAdmin):
    pass


class PlantAdmin(admin.ModelAdmin):
    list_display = (
        '__str__',
        '_moisture_needs',
        '_sunlight_needs',
        '_hardiness_zones',
        'garden_org_link',)


    def _moisture_needs(self, obj):
        return " | ".join(
            map(Plant.MOISTURE_LOOKUP.get, sorted(obj.moisture_needs)))

    def _sunlight_needs(self, obj):
        return " | ".join(
            map(Plant.SUNLIGHT_LOOKUP.get, sorted(obj.sunlight_needs)))

    def _hardiness_zones(self, obj):
        return " | ".join(
            map(Plant.HARDINESS_LOOKUP.get, sorted(obj.hardiness_zones)))

    def garden_org_link(self, obj):
        url = obj.garden_org_url
        return (
            f'<a target="garden_org" href="{url}">{obj.garden_org_id}</a>'
            if obj.garden_org_id else ''
        )
    garden_org_link.allow_tags = True


admin.site.register(models.User, UserAdmin)
admin.site.register(models.Project, ProjectAdmin)
admin.site.register(models.Controller, ControllerAdmin)
admin.site.register(models.ControllerVersion, ControllerVersionAdmin)
admin.site.register(models.FlowRateSensor, FlowRateSensorAdmin)
admin.site.register(models.PlantAssignment)
admin.site.register(models.Probe, ProbeAdmin)
admin.site.register(models.Valve, ValveAdmin)
admin.site.register(models.Zone, ZoneAdmin)

admin.site.register(plantdb.models.Plant, PlantAdmin)
