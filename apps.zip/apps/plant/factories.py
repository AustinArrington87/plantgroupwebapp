import factory
import factory.fuzzy
from factory.django import DjangoModelFactory as BaseFactory

from plant.models import (
    User, Controller, ControllerVersion, Probe, Project, Valve, ValveEvent, Zone
)


def sequential_name(what): return factory.Sequence(lambda n: "%s %03d" % (what, n))
def mcu_id_field(): return factory.fuzzy.FuzzyInteger(1000, 9999)


class UserFactory(BaseFactory):

    email = factory.fuzzy.FuzzyText(length=8)
    username = factory.fuzzy.FuzzyText(length=8)
    password = factory.PostGenerationMethodCall('set_password', 'password')

    class Meta:
        model = User


class ProjectFactory(BaseFactory):

    name = sequential_name("Project")

    class Meta:
        model = Project


class ZoneFactory(BaseFactory):

    project = factory.SubFactory(ProjectFactory)

    class Meta:
        model = Zone


class ControllerFactory(BaseFactory):

    zone = factory.SubFactory(ZoneFactory)
    version_id = 1
    mcu_id = mcu_id_field()

    class Meta:
        model = Controller


class ProbeFactory(BaseFactory):

    controller = factory.SubFactory(ControllerFactory)
    mcu_id = mcu_id_field()

    class Meta:
        model = Probe


class ValveFactory(BaseFactory):

    controller = factory.SubFactory(ControllerFactory)
    mcu_id = mcu_id_field()

    class Meta:
        model = Valve


class ValveEventFactory(BaseFactory):

    class Meta:
        model = ValveEvent
