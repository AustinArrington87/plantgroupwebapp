from django.conf.urls import include, url
from django.core.urlresolvers import reverse_lazy
from rest_framework.routers import DefaultRouter
from rest_framework_swagger.views import get_swagger_view

from . import views

# TODO: use drf-extensions for nested router
router = DefaultRouter()
router.register(r'projects', views.ProjectViewSet)
router.register(r'valves', views.ValveViewSet)
router.register(r'zones', views.ZoneViewSet)
# router.register(r'controller-configs', views.ControllerConfigViewSet)

schema_view = get_swagger_view(title='PLANT API')

urlpatterns = [
    url(r'^$', schema_view),
    url(r'^', include(router.urls)),
    url(
        r'^controllers/(?P<mcu_id>.*)/config/$',
        views.ControllerConfigView.as_view(),
        name='controller-config'
    ),
    url(
        r'flowrate/(?P<pk>.*)/total',
        views.get_sensor_total,
        name='flowrate-water-usage-stats'
    )
]
