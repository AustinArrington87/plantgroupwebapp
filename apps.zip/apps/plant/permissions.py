from rest_framework import permissions


ValvePermission = permissions.AllowAny


class AllowAnyGet(permissions.BasePermission):

    def has_permission(self, request, view):
        return request.method == 'GET'

    def has_object_permission(self, request, view, obj):
        return request.method == 'GET'


def OwnerPermission(getter):

    class _OwnerPermission(permissions.BasePermission):

        def has_object_permission(self, request, view, obj):
            return getter(obj).filter(id=request.user.id).exists()

    return _OwnerPermission