from django.conf.urls import include, url
from django.core.urlresolvers import reverse_lazy
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register(r'plants', views.PlantViewSet)

urlpatterns = [
    url(r'^', include(router.urls)),
    url(
        r'search',
        views.search,
        name='search'
    )
]
