import factory
import factory.fuzzy
from factory.django import DjangoModelFactory as BaseFactory

from plantdb.models import (
    Plant
)


class PlantFactory(BaseFactory):

    common_name = factory.fuzzy.FuzzyText(length=8)
    scientific_name = factory.fuzzy.FuzzyText(length=8)
    moisture_needs = [5]
    sunlight_needs = [5]
    hardiness_zones = [5]

    class Meta:
        model = Plant
