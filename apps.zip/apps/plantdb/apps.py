from django.apps import AppConfig


class PlantdbConfig(AppConfig):
    name = 'plantdb'
